<?php
$host = "localhost";
$user = "root";
$pass = "febrilia";
$dbname = "shigatsu";

$konek = mysql_connect($host, $user, $pass);
if(!$konek)
{
	echo "Tidak bisa koneksi ke database";
}
else
{
	mysql_select_db($dbname);
}
?>
