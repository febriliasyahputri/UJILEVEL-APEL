<?php
include '../../koneksi.php';
$id_barang = $_GET['id_barang'];
if(mysql_query("DELETE FROM tbl_barang WHERE id_barang = $id_barang")){
  header('location:../frmDataBarang.php');
}else {
  echo "<script>alert('Gagal Hapus Jenis Barang'); history.back();</script>";
}
 ?>
