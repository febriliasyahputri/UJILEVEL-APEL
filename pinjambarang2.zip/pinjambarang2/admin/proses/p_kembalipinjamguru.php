<?php
include '../../koneksi.php';
$id_pegawai      = $_GET['id_pegawai'];
$jumlah_pinjam = $_GET['jumlah_pinjam'];

$query = "SELECT * FROM
          tbl_pegawai AS p,
          tbl_pinjam AS pm,
          tbl_barang AS b
          WHERE
          p.`id_pegawai`=pm.`id_peminjam` AND
          b.`id_barang`=pm.`id_barang` AND
          pm.`id_peminjam` = $id_pegawai";
$select = mysql_query($query);
$no = 1;
while ($data = mysql_fetch_assoc($select)) {
  $qUpdatePinjam = "UPDATE tbl_pinjam SET status_pinjam = 1 WHERE id_pinjam = ".$data['id_pinjam'];
  $qUpdateBarang = "UPDATE tbl_barang SET status_barang = 0 WHERE id_barang = ".$data['id_barang'];
  $uUpdatePinjam = mysql_query($qUpdatePinjam);
  $uUpdateBarang = mysql_query($qUpdateBarang);
}
header('location:../frmDataPeminjaman.php');

 ?>
