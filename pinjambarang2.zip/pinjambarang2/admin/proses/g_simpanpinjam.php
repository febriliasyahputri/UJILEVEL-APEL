<?php
include '../../koneksi.php';
session_start();
$id_barang = $_POST['id_barang'];
$id_peminjam = $_POST['id_pegawai'];
$id_jenis_barang = $_POST['jenis_barang'];
$id_jenis_peminjam = '2';
$jumlah_pinjam = count($id_barang);
$waktu_pinjam = $_POST['waktu_pinjam'];
$catatan = $_POST['catatan'];

  for ($i=0; $i < count($id_barang); $i++) {
    // echo "<script>alert('$i');</script>";
    $query = "INSERT INTO tbl_pinjam(
              `id_peminjam`,
              `id_jenis_barang`,
              `id_barang`,
              `id_jenis_peminjam`,
              `jumlah_pinjam`,
              `waktu_pinjam`,
              `catatan`,
              `status_pinjam`
            ) VALUES(
              '$id_peminjam',
              '$id_jenis_barang',
              '$id_barang[$i]',
              '$id_jenis_peminjam',
              '$jumlah_pinjam',
              '$waktu_pinjam',
              '$catatan',
              '0'
            )";
    @$insert = mysql_query($query);
    @$query = "UPDATE tbl_barang SET status_barang = 1 WHERE id_barang = $id_barang[$i]";
    @$update = mysql_query($query);
  }
  header('location:../frmDataPeminjaman.php');
 ?>
