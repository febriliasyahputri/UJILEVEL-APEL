<?php
include '../../koneksi.php';
$id_jenis_barang = $_POST['id_jenis_barang'];
$nama_jenis = $_POST['nama_jenis'];
if(mysql_query("UPDATE tbl_jenis_barang SET nama_jenis = '$nama_jenis' WHERE id_jenis_barang = $id_jenis_barang")){
  header('location:../frmJenisBarang.php');
}else {
  echo "<script>alert('Gagal Ubah Jenis Barang'); history.back();</script>";
}
 ?>
