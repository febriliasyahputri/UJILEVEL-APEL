<?php
include '../../koneksi.php';
$nama_jenis = $_POST['nama_jenis'];
if(mysql_query("INSERT INTO tbl_jenis_barang(`nama_jenis`) VALUES('$nama_jenis')")){
  header('location:../frmJenisBarang.php');
}else {
  echo "<script>alert('Gagal Tambah Jenis Barang'); history.back();</script>";
}
 ?>
