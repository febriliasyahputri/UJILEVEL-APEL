<?php
include '../../koneksi.php';
$nama_siswa = $_POST['nama_siswa'];
$query = "SELECT * FROM tbl_siswa WHERE nama LIKE '%$nama_siswa%'";
$select = mysql_query($query);
$result = "";
if($select){
  if(mysql_num_rows($select) > 0){
    $html = "<table class='table'>
              <tr>
                <td>No</td>
                <td>Nama</td>
                <td>Kelas</td>
                <td>Opsi</td>
              </tr>";
    $no = 1;
    while ($data = mysql_fetch_assoc($select)) {
      $html .= '<tr>';
      $html .= '  <td>'.$no.'</td>';
      $html .= '  <td>'.$data['nama'].'</td>';
      $html .= '  <td>'.$data['kelas'].'</td>';
      $html .= '  <td><input type="radio" name="pilih_siswanya" class="pilih_siswanya" id_siswa="'.$data['id_siswa'].'" nama_siswa="'.$data['nama'].'" kelas="'.$data['kelas'].'" /></td>';
      $html .= '</tr>';
      $no++;
    }
    $html .= "</table>";
    $result = array(
      'result' => 1,
      'html' => $html
    );
  }else {
    $result = array(
      'result' => 0,
      'error' => mysql_error()
    );
  }
}else {
  $result = array(
    'result' => 0,
    'error' => mysql_error()
  );
}
echo json_encode($result);
?>
