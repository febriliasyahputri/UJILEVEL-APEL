<?php
 include('../../koneksi.php');
	if(isset($_FILES['gambar2'])){
      $errors= array();
      $file_name = $_FILES['gambar2']['name'];
      $file_size =$_FILES['gambar2']['size'];
      $file_tmp =$_FILES['gambar2']['tmp_name'];
      $file_type=$_FILES['gambar2']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['gambar2']['name'])));
      
      $expensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"../../assets/img/barang/".$file_name);
			$idbarang=$_POST['id_barang'];
			$id_jenis_barang = $_POST['slct1'];
			$stok=$_POST['stok_awal'];
			$gambar=$file_name;

			$query = "UPDATE tbl_barang SET id_jenis_barang = '$id_jenis_barang', 
                  stok_awal = '$stok', gambar = '$gambar' WHERE id_barang = '$idbarang'";
			if(!$input = mysql_query($query)){
				echo mysql_error();
			}else{
				header('location:../frmlihatdatabarang.php');
			}
      }else{
         print_r($errors);
      }
   }else{
      $idbarang=$_POST['id_barang'];
      $id_jenis_barang = $_POST['slct1'];
      $stok=$_POST['stok_awal'];
      $query = "UPDATE tbl_barang SET id_jenis_barang = '$id_jenis_barang', 
               stok_awal = '$stok' WHERE id_barang = '$idbarang'";
      if(!$input = mysql_query($query)){
         echo mysql_error();
      }else{
         header('location:../frmlihatdatabarang.php');
      }
   }
?>
