<?php
include '../../koneksi.php';
if(isset($_FILES['gambar'])){
    $errors= array();
    $file_name = $_FILES['gambar']['name'];
    $file_size =$_FILES['gambar']['size'];
    $file_tmp =$_FILES['gambar']['tmp_name'];
    $file_type=$_FILES['gambar']['type'];
    $file_ext=strtolower(end(explode('.',$_FILES['gambar']['name'])));

    $expensions= array("jpeg","jpg","png");

    if(in_array($file_ext,$expensions)=== false){
       $errors[]="Ekstensi File Tidak didukung!";
    }

    if($file_size > 2097152){
       $errors[]='File terlalu besar';
    }

    if(empty($errors)==true){
      move_uploaded_file($file_tmp,"../../assets/img/barang/".$file_name);
			$id_barang       = $_POST['id_barang'];
			$id_jenis_barang = $_POST['id_jenis_barang'];
			$nama_barang     = $_POST['nama_barang'];
			$merk            = $_POST['merk'];
			$kondisi         = $_POST['kondisi'];
			$tanggal         = $_POST['tanggal'];
			$keterangan      = $_POST['keterangan'];
			$gambar          = $file_name;

			$query = "UPDATE tbl_barang
                SET `id_jenis_barang` = $id_jenis_barang,
                `nama_barang` = '$nama_barang',
                `merk` = '$merk',
                `kondisi` = '$kondisi',
                `tanggal` = '$tanggal',
                `keterangan` = '$keterangan',
                `gambar` = '$gambar'
                WHERE `id_barang` = $id_barang";
			if(!$input = mysql_query($query)){
				echo mysql_error();
        // echo "<script>alert('Gagal Ubah Jenis Barang'); history.back();</script>";
			}else{
				header('location:../frmDataBarang.php');
			}
    }else{
      $id_barang       = $_POST['id_barang'];
      $id_jenis_barang = $_POST['id_jenis_barang'];
      $nama_barang     = $_POST['nama_barang'];
      $merk            = $_POST['merk'];
      $kondisi         = $_POST['kondisi'];
      $tanggal         = $_POST['tanggal'];
      $keterangan      = $_POST['keterangan'];
      $gambar          = $file_name;

      $query = "UPDATE tbl_barang
                SET `id_jenis_barang` = $id_jenis_barang,
                `nama_barang` = '$nama_barang',
                `merk` = '$merk',
                `kondisi` = '$kondisi',
                `tanggal` = '$tanggal',
                `keterangan` = '$keterangan',
                `gambar` = '$gambar'
                WHERE `id_barang` = $id_barang";
      if(!$input = mysql_query($query)){
        echo mysql_error();
        echo "<script>alert('Gagal Ubah Jenis Barang'); history.back();</script>";
      }else{
        header('location:../frmDataBarang.php');
      }
    }
}else {
  $id_barang       = $_POST['id_barang'];
  $id_jenis_barang = $_POST['id_jenis_barang'];
  $nama_barang     = $_POST['nama_barang'];
  $merk            = $_POST['merk'];
  $kondisi         = $_POST['kondisi'];
  $tanggal         = $_POST['tanggal'];
  $keterangan      = $_POST['keterangan'];
  $gambar          = $file_name;

  $query = "UPDATE tbl_barang
            SET `id_jenis_barang` = $id_jenis_barang,
            `nama_barang` = '$nama_barang',
            `merk` = '$merk',
            `kondisi` = '$kondisi',
            `tanggal` = '$tanggal',
            `keterangan` = '$keterangan',
            `gambar` = '$gambar'
            WHERE `id_barang` = $id_barang";
  if(!$input = mysql_query($query)){
    echo mysql_error();
    echo "<script>alert('Gagal Ubah Jenis Barang'); history.back();</script>";
  }else{
    header('location:../frmDataBarang.php');
  }
}
?>
