<?php

 include('../../koneksi.php');

	$idbarang=$_GET['id_barang'];

	$input = mysql_query("DELETE from tbl_barang where id_barang='$idbarang'") or die(mysql_error());
	header('location:../frmlihatdatabarang.php')

?>
