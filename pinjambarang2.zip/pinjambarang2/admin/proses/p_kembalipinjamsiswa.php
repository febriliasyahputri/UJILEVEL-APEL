<?php
include '../../koneksi.php';
$id_siswa      = $_GET['id_siswa'];
$jumlah_pinjam = $_GET['jumlah_pinjam'];

$query = "SELECT * FROM
          tbl_siswa AS s,
          tbl_pinjam AS pm,
          tbl_barang AS b
          WHERE
          s.`id_siswa`=pm.`id_peminjam` AND
          b.`id_barang`=pm.`id_barang` AND
          pm.`id_peminjam` = $id_siswa";
$select = mysql_query($query);
$no = 1;
while ($data = mysql_fetch_assoc($select)) {
  $qUpdatePinjam = "UPDATE tbl_pinjam SET status_pinjam = 1 WHERE id_pinjam = ".$data['id_pinjam'];
  $qUpdateBarang = "UPDATE tbl_barang SET status_barang = 0 WHERE id_barang = ".$data['id_barang'];
  $uUpdatePinjam = mysql_query($qUpdatePinjam);
  $uUpdateBarang = mysql_query($qUpdateBarang);
}
header('location:../frmDataPeminjaman.php');

 ?>
