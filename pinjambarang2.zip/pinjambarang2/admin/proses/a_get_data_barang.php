<?php
include '../../koneksi.php';
$id_jenis_barang = $_POST['id_jenis_barang'];
$query = "SELECT * FROM tbl_barang WHERE id_jenis_barang = $id_jenis_barang AND status_barang = 0";
$select = mysql_query($query);
$html = "";
$result = "";
if($select){
  if(mysql_num_rows($select) > 0){
    while ($data = mysql_fetch_assoc($select)) {
      $html .= '<option value="'.$data['id_barang'].'">'.$data['nama_barang'].'</option>';
    }
    $result = array(
      'result' => 1,
      'html' => $html
    );
  }else {
    $result = array(
      'result' => 0,
      'error' => mysql_error()
    );
  }
}else {
  $result = array(
    'result' => 0,
    'error' => mysql_error()
  );
}
echo json_encode($result);
 ?>
