<?php
include '../../koneksi.php';
session_start();
$id_barang = $_POST['id_barang'];
$id_peminjam = $_POST['id_siswa'];
$id_jenis_barang = $_POST['jenis_barang'];
$id_jenis_peminjam = '1';
$jumlah_pinjam = count($id_barang);
$waktu_pinjam = $_POST['waktu_pinjam'];
$waktu_kembali = $_POST['waktu_kembali'];
$catatan = $_POST['catatan'];

  for ($i=0; $i < count($id_barang); $i++) {
    // echo "<script>alert('$i');</script>";
    $query = "INSERT INTO tbl_pinjam(
              `id_peminjam`,
              `id_jenis_barang`,
              `id_barang`,
              `id_jenis_peminjam`,
              `jumlah_pinjam`,
              `waktu_pinjam`,
              `waktu_kembali`,
              `catatan`,
              `status_pinjam`
            ) VALUES(
              '$id_peminjam',
              '$id_jenis_barang',
              '$id_barang[$i]',
              '$id_jenis_peminjam',
              '$jumlah_pinjam',
              '$waktu_pinjam',
              '$waktu_kembali',
              '$catatan',
              '0'
            )";
    @$insert = mysql_query($query);
    @$query = "UPDATE tbl_barang SET status_barang = 1 WHERE id_barang = $id_barang[$i]";
    @$update = mysql_query($query);
  }
  header('location:../frmDataPeminjaman.php');
 ?>
