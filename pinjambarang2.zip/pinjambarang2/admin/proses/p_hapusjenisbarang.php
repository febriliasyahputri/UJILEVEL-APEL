<?php
include '../../koneksi.php';
$id_jenis_barang = $_GET['id_jenis_barang'];
if(mysql_query("DELETE FROM tbl_jenis_barang WHERE id_jenis_barang = $id_jenis_barang")){
  header('location:../frmJenisBarang.php');
}else {
  echo "<script>alert('Gagal Hapus Jenis Barang'); history.back();</script>";
}
 ?>
