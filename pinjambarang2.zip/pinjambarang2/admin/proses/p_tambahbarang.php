<?php

 include('../../koneksi.php');
	if(isset($_FILES['gambar'])){
      $errors= array();
      $file_name = $_FILES['gambar']['name'];
      $file_size =$_FILES['gambar']['size'];
      $file_tmp =$_FILES['gambar']['tmp_name'];
      $file_type=$_FILES['gambar']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['gambar']['name'])));
      
      $expensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"../../assets/img/barang/".$file_name);
			$idbarang=$_POST['id_barang'];
			$id_jenis_barang = $_POST['slct1'];
			$stok=$_POST['stok_awal'];
			$gambar=$file_name;

			$query = "INSERT INTO tbl_barang VALUES('$idbarang','$id_jenis_barang','$stok', '$stok', '$gambar')";
			if(!$input = mysql_query($query)){
				echo mysql_error();
			}else{
				header('location:../frmlihatdatabarang.php');
			}
      }else{
         print_r($errors);
      }
   }
?>
