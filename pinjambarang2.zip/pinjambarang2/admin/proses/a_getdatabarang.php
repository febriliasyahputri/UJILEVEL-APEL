<?php
include '../../koneksi.php';
$id_barang = $_POST['id_barang'];
$query = "SELECT * FROM tbl_barang, tbl_jenis_barang WHERE tbl_barang.id_jenis_barang=tbl_jenis_barang.id_jenis_barang AND id_barang = $id_barang";
$select = mysql_query($query);
$result = "";
if($select){
  if(mysql_num_rows($select) > 0){
    $data = mysql_fetch_assoc($select);
    $result = array(
      'result' => 1,
      'id_barang' => $data['id_barang'],
      'id_jenis_barang' => $data['id_jenis_barang'],
      'nama_barang' => $data['nama_barang'],
      'merk' => $data['merk'],
      'kondisi' => $data['kondisi'],
      'tanggal' => $data['tanggal'],
      'keterangan' => $data['keterangan'],
      'gambar' => $data['gambar']
    );
  }else {
    $result = array(
      'result' => 0,
      'error' => mysql_error()
    );
  }
}else {
  $result = array(
    'result' => 0,
    'error' => mysql_error()
  );
}
echo json_encode($result);
 ?>
