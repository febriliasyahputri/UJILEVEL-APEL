<?php

 ?>
 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <title>Tambah Laptop</title>
   </head>
   <body>
      
   </body>
 </html>
