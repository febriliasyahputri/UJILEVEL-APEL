<?php
include '../../koneksi.php';
$id_pinjam = $_GET['id_pinjam'];
if(mysql_query("DELETE FROM tbl_pinjam WHERE id_pinjam = $id_pinjam")){
  header('location:../kaprogdatapeminjaman.php');
}else {
  echo "<script>alert('Gagal Hapus Jenis Barang'); history.back();</script>";
}
 ?>