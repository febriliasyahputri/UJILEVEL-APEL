
   <!-- sidebar -->
 <div class="sidebar-wrapper shadow">
   <div class="sidebar-avatar">
     <div class="sidebar-avatar-icon">
       <img src="../assets/img/teacher_icon.png" class="img-circle" alt="Cinque Terre" width="150" height="150">
     </div>
     <div class="sidebar-avatar-name">
     </div>
     <div class="sidebar-avatar-level">
       Kepala Program Keahlian
     </div>
   </div>
   <!-- sidebar menu -->
   <div class="sidebar-menu">
     <div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="true">
       <div class="panel panel-default no-border no-radius" style="border-radius: 0px">
         <div class="panel-heading menu-parent" role="tab" id="headingOne" style="border-radius: 0px">
           <h4 class="panel-title" style="text-align: left;">
             <a href="kaprogdatabarang.php"><span class="fa fa-tag" style="font-size: 20px;"></span>&nbsp;&nbsp; Data Barang</a>

           </h4>
         </div>
         <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" style="border-radius: 0px">

         </div>
       </div>

       <div class="panel panel-default no-border no-radius" style="border-radius: 0px">
         <div class="panel-heading menu-parent" role="tab" id="headingOne" style="border-radius: 0px">
           <h4 class="panel-title" style="text-align: left;">
             <a href="kaprogdatapeminjaman.php"><span class="fa fa-folder" style="font-size: 20px;"></span>&nbsp;&nbsp; Data Peminjaman</a>

           </h4>
         </div>
         <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" style="border-radius: 0px">

         </div>
       </div>
        <div class="panel panel-default no-border no-radius" style="border-radius: 0px">
         <div class="panel-heading menu-parent" role="tab" id="headingOne" style="border-radius: 0px">
           <h4 class="panel-title" style="text-align: left;">
             <a href="rumahkaprog.php"><span class="fa fa-file" style="font-size: 20px;"></span>&nbsp;&nbsp; Laporan </a>

           </h4>
         </div>
         <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" style="border-radius: 0px">

         </div>
       </div>
         </div>
       </div>
     </div>
   </div>
 </div>
 <!-- Akhir Sidebar -->
