<?php
require '../assets/fpdf/fpdf.php';
$mysqli = new mysqli("localhost","root","","shigatsu");
$sql = "SELECT * FROM
           tbl_pegawai AS pg,
           tbl_pinjam AS pm,
           tbl_barang AS b,
           tbl_jenis_peminjam AS jp
           WHERE
           pg.`id_pegawai`=pm.`id_peminjam` AND
           b.`id_barang`=pm.`id_barang` AND
           jp.`id_jenis_peminjam`=pm.`id_jenis_peminjam` AND
           pm.`id_peminjam`";
$select = $mysqli->query($sql);
$i = 1;

//Inisiasi untuk membuat header kolom
$column_no = "";
$column_nama = "";
$column_jenis_peminjam = "";
$column_namabarang = "";
$column_waktu = "";
$column_status_pinjam = "";

//For each row, add the field to the corresponding column


while($data = $select->fetch_object())
{

    $no = $i.".";
    $nama = $data->nama;
    $jenis_peminjam = $data->jenis_peminjam;
    $namabarang = $data->nama_barang;
    $waktu = $data->waktu_pinjam;
    $status_pinjam = $data->status_pinjam;
    if($status_pinjam == "0"){
      $status_pinjam = "Sedang meminjam";
    }else{
      $status_pinjam = "Sudah dikembalikan";
    }

    $column_no = $column_no.$no."\n";
    $column_nama = $column_nama.$nama."\n";
    $column_jenis_peminjam = $column_jenis_peminjam.$jenis_peminjam."\n";
    $column_namabarang = $column_namabarang.$namabarang."\n";
    $column_waktu = $column_waktu.$waktu."\n";
    $column_status_pinjam = $column_status_pinjam.$status_pinjam."\n";

$i = $i+1;
}

//Create a new PDF file
$pdf = new FPDF('p','mm',array(297,210)); //L For Landscape / P For Portrait
$pdf->AddPage();
//Menambahkan Gambar
//$pdf->Image('../foto/logo.png',10,10,-175);

$pdf->SetFont('Arial','B',18);
$pdf->Cell(80);
$pdf->Cell(30,10,'LAPORAN DATA PINJAM GURU',0,0,'C');
$pdf->Ln();

//Fields Name position
$Y_Fields_Name_position = 30;
$position = -10;
//First create each Field Name
//Gray color filling each Field Name box
$pdf->SetFillColor(110,180,230);
//Bold Font for Field Name
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(15+$position);
$pdf->Cell(10,8,'No',1,0,'C',1);
$pdf->SetX(25+$position);
$pdf->Cell(40,8,'Nama',1,0,'C',1);
$pdf->SetX(65+$position);
$pdf->Cell(35,8,'Jenis Peminjam',1,0,'C',1);
$pdf->SetX(100+$position);
$pdf->Cell(25,8,'Nama Barang',1,0,'C',1);
$pdf->SetX(125+$position);
$pdf->Cell(45,8,'waktu pinjam',1,0,'C',1);
$pdf->SetX(170+$position);
$pdf->Cell(45,8,'Status Pinjam',1,0,'C',1);
$pdf->Ln();

//Table position, under Fields Name
$Y_Table_Position = 38;

//Now show the columns
$pdf->SetFont('Arial','',10);

$pdf->SetY($Y_Table_Position);
$pdf->SetX(15+$position);
$pdf->MultiCell(10,6,$column_no,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(25+$position);
$pdf->MultiCell(40,6,$column_nama,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(65+$position);
$pdf->MultiCell(35,6,$column_jenis_peminjam,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(100+$position);
$pdf->MultiCell(25,6,$column_namabarang,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(125+$position);
$pdf->MultiCell(45,6,$column_waktu,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(170+$position);
$pdf->MultiCell(45,6,$column_status_pinjam,1,'C');
$pdf->Output();
?>
