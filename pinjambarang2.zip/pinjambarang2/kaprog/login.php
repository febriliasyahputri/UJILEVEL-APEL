<?php
session_start();
if(isset($_SESSION['login_user'])){
  header ('location:kaprogdatabarang.php');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Login Kaprog</title>

      <!-- Bootstrap -->
      <link rel="stylesheet" href="../assets/css/bootstrap.css"/>
      <link rel="stylesheet" href="../assets/css/font-awesome.css"/>
      <!-- CSS -->
      <link rel="stylesheet" href="../assets/css/styles.css"/>
      <link rel="stylesheet" href="../assets/css/form-elements.css">
      <link href='../assets/img/icon.png' rel='shortcut icon'>
      <!--Script Javascript-->
      <script type="text/javascript" src="../assets/js/jquery-2.1.4.js"></script>
      <script src="../assets/js/jquery.backstretch.min.js"></script>
      <script type="text/javascript" src="../assets/js/bootstrap.js"></script>
      <style media="screen">
	  button.btn {
		height: 35px;
		margin: 0;
		padding: 0 20px;
		vertical-align: middle;
		background: #4aaf51;
		border: 0;
		font-family: 'Roboto', sans-serif;
		font-size: 16px;
		font-weight: 300;
		line-height: 0px;
		}
      </style>
  </head>
  <body background="../assets/img/laptop.jpg">

  <div class="top-content">
    <div class="inner-bg">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-sm-offset-3 form-box">
            <div class="form-top">
              <div class="form-top-left">
                <h4>SELAMAT DATANG KAPROG</h4>
                  <p>Masukkan Username dan Password</p>
              </div>
              </div>
              <div class="form-bottom">
            <form action="" method="post" class="login-form">
              <div class="form-group">
                <label class="sr-only" for="form-username">Username</label>
                  <input type="text" name="username" placeholder="Username" required="" class="form-username form-control" id="form-username">
                </div>
                <div class="form-group">
                  <label class="sr-only" for="form-password">Password</label>
                  <input type="password" name="password" placeholder="Password" required="" class="form-password form-control" id="form-password">
                </div>
                <?php
										include '../koneksi.php';

										if(isset($_POST['login'])) {
										$username = $_POST['username'];
										$password = $_POST['password'];
										$sql = mysql_query("SELECT * FROM tbl_user WHERE username='$username' && password=MD5('$password') AND level = 'kaprog'");
										$num = mysql_num_rows($sql);
										if($num>0) {
											$_SESSION['login_user']=$username;
											header('location:rumahkaprog.php');
										}else{
											echo "Username or Password Invalid";
										}
										}
									?>
                <button type="submit" class="btn" name="login">Login</button>
            </form>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  </body>
</html>
