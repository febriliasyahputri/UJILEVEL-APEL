<!DOCTYPE html>
<html>
 <head>
   <title>Peminjaman Barang Laboratorium Komputer SMK Negeri 1 Ciomas</title>

      <!-- Bootstrap -->
      <link rel="stylesheet" href="../assets/css/bootstrap.css"/>
      <link rel="stylesheet" href="../assets/css/font-awesome.css"/>
      <link rel="stylesheet" href="../assets/css/custom.css"/>
      <link href='../assets/img/icon.png' rel='shortcut icon'>
      <!-- Java Script -->
      <script type="text/javascript" src="../assets/js/jquery-2.1.4.js"></script>
      <script type="text/javascript" src="../assets/js/bootstrap.js"></script>

 </head>
 <body>
   <?php
    include "view/sidebar.php";
    include "view/navbar.php";
   ?>
   <!-- Static navbar -->
   <div class="content" style="background-color:#ecf0f1;">
    <h2 style="margin-left:20px;"><span class="fa fa-tag" style="font-size: 30px;"></span>&nbsp;Pinjam Barang</h2>
    <div class="col-md-12">
      <ol class="breadcrumb" style="background-color:#FAFAFA;">
      <li><a href="#">Laporan</a></li>
      </ol>
        <!-- <div class="container"> -->
        <div class="panel-body">
           <div class="container-fluid" style="background: #FFF; padding: 10px; border-top: 3px solid #2980b9;">
             <div class="btn-group btn-group-justified">
                <a href="laporandatabarang.php" target="_blank" class="btn btn-success">Data Inventaris</a>
                <a href="laporanpinjammurid.php" target="_blank" class="btn btn-warning">Data Pinjam Siswa</a>
                <a href="laporanpinjamguru.php" target="_blank" class="btn btn-danger">Data Pinjam Guru</a>
             </div>
           </div>
      </div>

        <!-- </div> -->
      </div>
    </div>


 </body>
</html>
